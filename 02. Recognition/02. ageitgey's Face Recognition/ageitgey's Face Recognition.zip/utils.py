def log(msg):
    print()
    print('*' * 100)
    print(msg)
    print('*' * 100)